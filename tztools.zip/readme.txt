TIME ZONE TOOLS
===============

Time Zone Tools is a set of scripts for generating a structured timezone list
for use by various OS/2 applications.  It requires the data files from the
open source Time Zone Database ('tzdata'), which are normally available from:
    https://www.iana.org/time-zones/repository/tzdata-latest.tar.gz


USAGE
-----

1.  Download and unpack the latest tzdata (see the link above) into a working
    directory.

2.  Make sure names.* is in the same directory as makedb.cmd and makelst.cmd.
    Translate names.* as needed (see below).

3.  Run 'makedb xx /t:<path>' where 'xx' is the language in which you want to
    generate the timezone list (a corresponding 'names.xx' file must exist for
    that language), and <path> is the directory (relative or full path) in which
    the tzdata files were placed in step (1).  This should generate the file
    ZONEINFO.xx, which is a binary file in OS/2 profile (INI) format.  (This
    file is intended for use with UniClock, but is also used as an intermediate
    format for the text-based lists.)

4.  To generate the text-based lists from the ZONEINFO.xx file:

     - Run 'makelst /i xx' to generate the list of timezones in a format usable
       by the ArcaOS graphical installer.  The generated file will be called
       TIMEZONE.PG - it cannot be used by the installer directly; rather, its
       contents should be pasted into the appropriate place in the locale page
       definition scripts.

     - Run 'makelst xx' to generate the list of timezones in a format usable by
       the TIMESET program.  The generated file will be called TZ_xx.LST, and
       should be directly usable by TIMESET.


TRANSLATION
-----------

Copy the file 'names.en' to 'names.xx' (where 'xx' is the two-letter code for 
your language).  See the comments at the top of the file for translation 
instructions.  Note that only the third and fourth columns should be translated
- the first two columns (country code and city-zone name) must NOT be modified.


-- 
Alex Taylor
August 2019
alex@altsan.org